
===============
Frozen v1.1.0.7
===============

This is Version 1.1.0.7 of Frozen for OSX (Intel). It contains:

- Frozen-Qt.dmg - The GUI version of Frozen - the standard wallet for MacOS
- frozend       - The frozen daemon. Use it if you want to run Frozen without graphical interface
- frozen.conf   - A sample Frozen configuration file
- md5sum.txt    - The MD5-sum of each of the binaries above
- readme.txt    - This text
- Makefile      - Helps to generate md5sum.txt


LOCATION OF frozen.conf
-----------------------

The location of a custom frozen.conf will probably be here:

    /Users/m/Library/Application Support/Frozen/frozen.conf


BUILD information
-----------------

The executables are build basically according to the process to build the Bitcoin-binaries
described in doc/build-osx.md.


FROZEN resources
----------------

    o Official FZ forum:        http://frozencoin.org/forum/index.php
    o Official Github sources:  https://github.com/fzcoin/frozencoin

